# pooII

Video simulador: https://www.youtube.com/watch?v=CsRfFhrNtho&t=26s

Artigo: https://arxiv.org/pdf/1108.5211v1.pdf
