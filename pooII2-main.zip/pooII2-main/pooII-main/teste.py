from classes.simulador import *

from classes.steffan import *

Simulador().rodarSimulacoes(10, True, 72,6)
#Simulador().rodarSimulacoes(10, True, 72, 6)